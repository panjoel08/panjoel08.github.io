
var lokasi ="pondok aren"; // lokasi mu
var Clock = "24h"; // choose between "12h" or "24h"
var Lang = "id"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var TextColor = "#5BE8A4"; 
var CityColor = "indigo"; 
var MasjidColor = "lightgreen"; 
var MoonColor = "grey";