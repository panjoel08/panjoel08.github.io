// code by panjoel
// setting provinsi di sini
// default 0 DKI jakarta 

var kota = "0";

// [0]Provinsi: DKI Jakarta
// [1]Provinsi: Jawa Barat
// [2]Provinsi: Jawa Timur
// [3]Provinsi: Jawa Tengah
// [4]Provinsi: Sulawesi Selatan
// [5]Provinsi: Banten
// [6]Provinsi: Nusa Tenggara Barat
// [7]Provinsi: Papua
// [8]Provinsi: Bali
// [9]Provinsi: Sumatera Barat
// [10]Provinsi: Kalimantan Selatan
// [11]Provinsi: Kalimantan Tengah
// [12]Provinsi: Sumatera Selatan
// [13]Provinsi: Kalimantan Timur
// [14]Provinsi: Kalimantan Utara
// [15]Provinsi: Sumatera Utara
// [16]Provinsi: Daerah Istimewa Yogyakarta
// [17]Provinsi: Kepulauan Riau
// [18]Provinsi: Kalimantan Barat
// [19]Provinsi: Sulawesi Tenggara
// [20]Provinsi: Sulawesi Tengah
// [21]Provinsi: Lampung
// [22]Provinsi: Riau
// [23]Provinsi: Sulawesi Utara
// [24]Provinsi: Sulawesi Barat
// [25]Provinsi: PaPua Barat
// [26]Provinsi: Maluku Utara
// [27]Provinsi: Jambi
// [28]Provinsi: Maluku
// [29]Provinsi: KePulauan Bangka Belitung
// [30]Provinsi: Gorontalo
// [31]Provinsi: Bengkulu
// [32]Provinsi: Aceh
// [33]Provinsi: Nusa Tenggara Timur

