//author panjoel08
var city = "pondok aren"; // lokasi Huruf kecil
var Clock = "24h"; // choose between "12h" or "24h"
var Lang = "id"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var MasjidWarna = "#45549e"; 
var kotakWarna = ""; 
var kotaWarna = ""; 
var TextColor = ""; 
